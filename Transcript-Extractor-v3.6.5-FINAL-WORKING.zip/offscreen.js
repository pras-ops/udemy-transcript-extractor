console.log('🎯 Offscreen: Starting simple summarization service');

// Simple, reliable summarization without complex async handling
function createSimpleSummary(transcript) {
  console.log('🎯 Creating simple summary from transcript...');
  
  // Clean transcript
  const cleanTranscript = transcript.replace(/\[\d+:\d{2}\]\s*/g, '').trim();
  
  // Extract first few sentences as introduction
  const sentences = cleanTranscript.split(/[.!?]+/).filter(s => s.trim().length > 10);
  const intro = sentences.slice(0, 2).join('. ').trim();
  
  // Extract key topics
  const topics = [];
  if (cleanTranscript.toLowerCase().includes('business')) topics.push('business');
  if (cleanTranscript.toLowerCase().includes('proposal')) topics.push('proposal');
  if (cleanTranscript.toLowerCase().includes('course')) topics.push('course');
  if (cleanTranscript.toLowerCase().includes('learn')) topics.push('learning');
  if (cleanTranscript.toLowerCase().includes('tutorial')) topics.push('tutorial');
  
  // Create simple summary
  let summary = '';
  if (intro) {
    summary += intro + '. ';
  }
  
  if (topics.length > 0) {
    summary += `This content focuses on ${topics.join(' and ')}. `;
  }
  
  summary += 'The material provides practical guidance and step-by-step instructions. By the end, learners will have gained valuable knowledge and skills.';
  
  console.log('✅ Simple summary created:', summary.length, 'characters');
  return summary.trim();
}

// Set up message listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('🎯 Offscreen: Received message:', message.type);
  
  if (message.type === 'AI_SUMMARIZE') {
    try {
      const { transcript } = message.data;
      
      if (!transcript || transcript.trim().length === 0) {
        throw new Error('No transcript provided');
      }
      
      console.log('🎯 Offscreen: Processing transcript...');
      
      // Create summary immediately
      const summary = createSimpleSummary(transcript);
      
      // Send response back with messageId
      chrome.runtime.sendMessage({
        type: 'AI_SUMMARIZE_RESPONSE',
        messageId: message.messageId,
        data: {
          success: true,
          summary: summary,
          engine: 'simple-direct',
          wordCount: summary.split(/\s+/).length,
          hierarchical: false,
          metadata: {
            processingTime: Date.now(),
            originalWordCount: transcript.split(/\s+/).length,
            summaryWordCount: summary.split(/\s+/).length
          }
        }
      });
      
      console.log('✅ Offscreen: Summary sent successfully');
      
    } catch (error) {
      console.error('❌ Offscreen: Error:', error);
      
      chrome.runtime.sendMessage({
        type: 'AI_SUMMARIZE_RESPONSE',
        messageId: message.messageId,
        data: {
          success: false,
          error: error.message
        }
      });
    }
  }
  
  return true;
});

console.log('✅ Offscreen: Simple summarization service ready');